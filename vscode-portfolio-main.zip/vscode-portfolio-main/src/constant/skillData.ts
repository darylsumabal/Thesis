export const skill = [
  {
    id: 1,
    name: "HTML",
    image: "html.svg",
  },
  {
    id: 2,
    name: "CSS",
    image: "css.svg",
  },
  {
    id: 3,
    name: "SCSS",
    image: "sass.svg",
  },
  {
    id: 4,
    name: "TAILWINDCSS",
    image: "tailwindcss.svg",
  },
  {
    id: 5,
    name: "JAVASCRIPT",
    image: "javascript.svg",
  },
  {
    id: 6,
    name: "TYPESCRIPT",
    image: "typescript.svg",
  },
  {
    id: 7,
    name: "REACT",
    image: "react_ts.svg",
  },
  {
    id: 8,
    name: "REDUX TOOLKIT",
    image: "redux.svg",
  },
  {
    id: 9,
    name: "TANSTACK QUERY",
    image: "tanstack.png",
  },
  {
    id: 10,
    name: "LARAVEL API",
    image: "laravel.svg",
  },
  {
    id: 12,
    name: "MYSQL",
    image: "mysql.svg",
  },
  {
    id: 13,
    name: "GITHUB",
    image: "github.svg",
  },
];
