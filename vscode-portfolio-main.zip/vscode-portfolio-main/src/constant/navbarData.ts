export const data = [
  {
    id: 1,
    slug: "/home",
    image: "react_ts.svg",
    filename: "home.tsx",
    alt: "home",
  },
  {
    id: 2,
    slug: "/about",
    image: "html.svg",
    filename: "about.html",
    alt: "about",
  },
  {
    id: 3,
    slug: "/contact",
    image: "css.svg",
    filename: "contact.css",
    alt: "contact",
  },
  {
    id: 4,
    slug: "/project",
    image: "javascript.svg",
    filename: "project.js",
    alt: "project",
  },
  {
    id: 5,
    slug: "/skills",
    image: "json.svg",
    filename: "skills.json",
    alt: "skills",
  },
  {
    id: 6,
    slug: "/github",
    image: "markdown.svg",
    filename: "github.md",
    alt: "github",
  },
];
