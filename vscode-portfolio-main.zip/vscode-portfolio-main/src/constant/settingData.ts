export const settingData = [
  {
    id: 1,
    name: "One Dark",
    image: "onedark.webp",
    theme: "dark",
  },
  {
    id: 2,
    name: "Dracula",
    image: "dracula.webp",
    theme: "dracula",
  },
  {
    id: 3,
    name: "Night Owl",
    image: "night-owl.webp",
    theme: "night",
  },
  {
    id: 4,
    name: "Synthwave",
    image: "synthwave.webp",
    theme: "synthwave",
  },
  {
    id: 5,
    name: "Ayu Dark",
    image: "ayu.webp",
    theme: "sunset",
  },
  {
    id: 6,
    name: "Halloween Dark",
    image: "halloween.webp",
    theme: "halloween",
  },
];
