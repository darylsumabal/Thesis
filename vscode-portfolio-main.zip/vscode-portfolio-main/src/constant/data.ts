export const contactData = [
  {
    id: 1,
    title: "Reach Out Via Socials",
    name: "social",
    socials: {
      facebook: "https://web.facebook.com/LEGENDARYL.SUMABAL",
      gmail: "darylsumabal123@gmail.com",
      github: "https://github.com/darylsumabal",
      linkedin: "https://www.linkedin.com/in/daryl-sumabal-11b5b6265/",
    },
  },
];

export const aboutData = [
  {
    id: 1,
    title: "A Little Bit About Me",
  },
];
